﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        double imc, peso, altura;

        private void TxtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida");
                // txtAltura.Focus():
            }
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            if ((double.TryParse(txtPesoAtual.Text, out peso)) && (double.TryParse(txtAltura.Text, out altura)))
            {
                if (altura != 0)
                {
                    imc = peso / Math.Pow(altura,2);
                    imc = Math.Round(imc, 1);
                    txtIMC.Text = imc.ToString();

                    if (imc < 18.5)
                        MessageBox.Show("Magrão");
                    else if(imc < 24.9)
                        MessageBox.Show("Normal");
                    else if (imc < 29.9)
                        MessageBox.Show("Sobrepeso");
                    else if (imc < 39.9)
                        MessageBox.Show("Obesidade");
                    else
                        MessageBox.Show("Obesidade Grave");
                }
                else
                {
                    MessageBox.Show("Altura inválida!");
                    txtAltura.Focus();
                }
                //BtnLimpar_Click(sender, e);
            }
            else
                MessageBox.Show("Números inválidos!!");
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtPesoAtual.Text = "";
            txtAltura.Clear();
            txtIMC.Text = String.Empty;

        }

        private void TxtPesoAtual_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPesoAtual.Text, out peso))
            {
                MessageBox.Show("Peso inválido");
                // txtAltura.Focus():
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
