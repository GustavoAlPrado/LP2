﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Calculadora : Form
    {
        double numero1, numero2, resultado;


        public Calculadora()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {





        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TxtNum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out numero2))
            {
                MessageBox.Show("Número 2 inválido!");
            }
        }

        private void BtnSoma_Validated(object sender, EventArgs e)
        {
        }

        private void Btnsub_Validated(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) && Double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 - numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números inválidos!");
        }

        private void BtnMult_Validated(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) && Double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 * numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números inválidos!");
        }

        private void BtnDiv_Validated(object sender, EventArgs e)
        {

        }

        private void TxtResultado_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnSoma_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) && Double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 + numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void Btnsub_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) && Double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 - numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) && Double.TryParse(txtNum2.Text, out numero2))
            {
                resultado = numero1 * numero2;
                txtResultado.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números inválidos!");
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNum1.Text, out numero1) && Double.TryParse(txtNum2.Text, out numero2))
            {
                if (numero2 == 0)
                {
                    MessageBox.Show("Não é possivel dividir por 0!");
                }
                else
                {
                    resultado = numero1 / numero2;
                    txtResultado.Text = resultado.ToString();
                }
            }
            else
                MessageBox.Show("Números inválidos!");
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();

        }

        private void TxtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text,out numero1))
            {
                MessageBox.Show("Número 1 inválido!");
            }

        }
    }
}
